# FastAPI Backend for Hive
